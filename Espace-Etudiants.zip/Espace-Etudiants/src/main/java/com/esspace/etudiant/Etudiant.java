/**
 * 
 */
package com.esspace.etudiant;

import java.sql.Date;

/**
 * 
 */
public class Etudiant {
   
   private int id;
   private String nom;
   private String prenom;
   private Date datenais;
   private String filiere;
   
   
   
   
   public Etudiant() {
	super();
	// TODO Auto-generated constructor stub
}

/**
    * 
    * @param id
    * @param nom
    * @param prenom
    * @param datenais
    * @param filiere
    */
   
   public Etudiant(int id, String nom, String prenom, Date datenais, String filiere) {
	super();
	this.id = id;
	this.nom = nom;
	this.prenom = prenom;
	this.datenais = datenais;
	this.filiere = filiere;
}

/**
    * 
    * @return the id
    */
public int getId() {
	return id;
}

/**
 * 
 * @return the id to set
 */
public void setId(int id) {
	this.id = id;
}
public String getNom() {
	return nom;
}
public void setNom(String nom) {
	this.nom = nom;
}
public String getPrenom() {
	return prenom;
}
public void setPrenom(String prenom) {
	this.prenom = prenom;
}
public Date getDatenais() {
	return datenais;
}
public void setDatenais(Date datenais) {
	this.datenais = datenais;
}
public String getFiliere() {
	return filiere;
}
public void setFiliere(String filiere) {
	this.filiere = filiere;
}

}
