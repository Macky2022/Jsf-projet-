package com.esspace.etudiant;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;


/**
 * 
 */

@RequestScoped
@Named
public class etudiantEJB {
	private Etudiant etudiant;
	private List<Etudiant>listeEtudiants;
	private Date date;
	private boolean modiff = false;
	private static int etdId;


	public etudiantEJB() {
		  //TODO Auto-generated constructor stub
		  etudiant = new Etudiant();
	   }
	
	
	public Connection connect() {
		try  {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/acc-pedagogic","root","");
			return con;
		}catch(ClassNotFoundException c) {
			//TODO Auto-generated catch block
			c.printStackTrace();
			Connection con = null ;
			return con ;
		}catch (SQLException c) {
			//TODO Auto-generated catch block
					c.printStackTrace();
					Connection con = null ;
					return con ;
		}
	  }
	
	
	public List<Etudiant> afficheEtudiants() {
		 listeEtudiants = new ArrayList<Etudiant>();
		 String lue = "Select * from identite";
		 try{
			 PreparedStatement ps = connect().prepareStatement(lue);
			 
		     ResultSet res = ps.executeQuery();
			 
			 while(res.next()) {
				 Etudiant etds = new Etudiant();
				 etds.setId(res.getInt("id"));
				 etds.setNom(res.getString("nom"));
				 etds.setPrenom(res.getString("prenom"));
				 etds.setDatenais(res.getDate("datenais"));
				 etds.setFiliere(res.getString("filiere"));
				 listeEtudiants.add(etds);
			 }
			 return listeEtudiants;
		 }catch(SQLException c) {
			//TODO Auto-generated catch block
				c.printStackTrace();
			    return listeEtudiants; 
		 }
	 }
	

    public void ajoutEtudiant() {
    	//la requet sql
    	String lue ="insert into etudiant(nom,prenom,datenais,INE, filiere)value(?,?,?,?,)";
    	etudiant.setDatenais(convDate(date));
    	try{
    	  //preparation de la requete
    		PreparedStatement ps =connect().prepareStatement(lue);
    		//ajout dans la requet sql
    		ps.setString(1,etudiant.getNom());
    		ps.setString(2,etudiant.getPrenom());
    		ps.setDate(3,etudiant.getDatenais());
    		ps.setString(4,etudiant.getFiliere());
    		//execution de la requet
    		ps.execute();
    		
    		afficheEtudiants();
    		etudiant = new Etudiant();
    		date = null;
    		
    	}catch(SQLException c1) {
    		//TODO Auto-generated catch block
			c1.printStackTrace();
    	}
   }
    
    public void deleteEtudiant(Etudiant etds) {
    	String lue="delete from etudiant where id= ?";
    	try{PreparedStatement ps = connect().prepareStatement(lue);
    	ps.setInt(1, etds.getId());
    	ps.execute();
    	}catch(SQLException c1) {
    		//TODO Auto-generated catch block
			c1.printStackTrace();
    	}
    }
    
    public void affiche(Etudiant etd) {
    	modiff=true;
    	etdId=etd.getId();
    	date=etd.getDatenais();
    	etudiant =etd;
    }
    

    public void modiffEtudiant() {
    	 etudiant.setDatenais(convDate(date));
    	
    	try{
    		String lue ="UPDATE etudiant SET  nom = ?,prenom = ?,datenais = ?, filiere = ? WERE id = ?";
    		PreparedStatement ps =connect().prepareStatement(lue);
    		
    		ps.setString(1,etudiant.getNom());
    		ps.setString(2,etudiant.getPrenom());
    		ps.setString(4,etudiant.getFiliere());
    		ps.setDate(3,etudiant.getDatenais());
    		ps.setInt(5,etdId);
    		
    		System.out.println(ps);
    		
    		ps.executeUpdate();
    		afficheEtudiants();
    		etudiant = new Etudiant();
    		date = null;
    	}catch (SQLException c1) {
    		//TODO Auto-geneated catch block
    		c1.printStackTrace();
    	}
    }
    		
    
    public java.sql.Date convDate(java.util.Date calendarDate){
    	 return new java.sql.Date(calendarDate.getTime());
 
    }
    public int getEtdId() {
		return etdId;
	}


	public void setEtdId(int etdId) {
		etudiantEJB.etdId = etdId;
	}

    /**
     * 
     * @return the modiff
     */
    
    public boolean isModiff() {
    	return modiff;
    }

    public void setModiff(boolean modiff) {
    	this.modiff = modiff;
    }
    /**
     * 
     * @return the pisteEtudiant
     */
	/*
	 * the piste etudiant
	 */
public List<Etudiant> getPisteEtudiant() {
		return afficheEtudiants();
	}


/**
 * the Etudiant
 * @return
 */
	public Etudiant getEtudiant() {
		return etudiant;
	}

	public void setEtudiant(Etudiant etudiant) {
		this.etudiant = etudiant;
	}

	public List<Etudiant> getListeEtudiants() {
		return listeEtudiants;
	}

	public void setListeEtudiants(List<Etudiant> listeEtudiants) {
		this.listeEtudiants = listeEtudiants;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	
}
